
<!DOCTYPE html>
<html>
<body>

<h1>Test page</h1>

<?php
echo "Hello World!";
?>

</body>
</html>